public interface Angle {
    public int getEdge();
}
