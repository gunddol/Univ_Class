public class Shape {
    public double area;

    public Shape(double _area){
        this.area = _area;
    }

    public double getArea(){
        return area;
    }
}
