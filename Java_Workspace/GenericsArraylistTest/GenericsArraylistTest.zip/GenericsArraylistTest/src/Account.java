public class Account<T> {
    public T data;

    public Account(T data){
        this.data = data;
    }
}
