public class Avante extends Car {

    public Avante(){

    }
}
