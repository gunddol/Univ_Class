public class Car {
    public String name;

    public Car(){
    }
}
