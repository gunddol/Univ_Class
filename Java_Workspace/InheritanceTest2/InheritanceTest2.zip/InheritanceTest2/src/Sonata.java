public class Sonata extends Car {

    public Sonata(){
    }
}
