public class Ambulance extends Car {
    public void drive(){
        System.out.println("응급차가 출발합니다.");
    }

    public void printOilType(){
        System.out.println("응급차는 경유를 사용합니다.");
    }
}
