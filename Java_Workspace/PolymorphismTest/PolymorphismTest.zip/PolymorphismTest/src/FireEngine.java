public class FireEngine extends Car {
    public void drive(){
        System.out.println("소방차가 출발합니다.");
    }

    public void printOilType(){
        System.out.println("소방차는 경유를 사용합니다.");
    }
}
