public class Motocycle extends Vehicle {
    public void drive(){
        System.out.println("오토바이가 출발합니다.");
    }

    public void printOilType(){
        System.out.println("오토바이는 휘발유를 사용합니다.");
    }

    public void printWheelCount(){
        System.out.println("바퀴 개수 : 2");
    }
}
