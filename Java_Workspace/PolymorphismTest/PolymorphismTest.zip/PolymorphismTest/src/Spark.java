public class Spark extends Car {
    public void drive(){
        System.out.println("Spark가 출발합니다.");
    }

    public void printOilType(){
        System.out.println("Spark는 휘발유를 사용합니다.");
    }
}
