public abstract class Vehicle {
    public abstract void printOilType();

    public abstract void printWheelCount();

    public void drive(){

    }
}
