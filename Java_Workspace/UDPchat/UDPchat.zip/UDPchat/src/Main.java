public class Main {
    public static void main(String[] args){
        UDPServer us = new UDPServer();
        us.start();
       // UDPClient uc = new UDPClient();
       // uc.start();
    }
}
